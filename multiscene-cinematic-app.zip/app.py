from flask import Flask, render_template, request
from diffusers import StableDiffusionPipeline
import torch, cv2, os, uuid

app = Flask(__name__)

pipe = StableDiffusionPipeline.from_pretrained(
    "runwayml/stable-diffusion-v1-5",
    torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32
).to("cuda" if torch.cuda.is_available() else "cpu")

def split_into_scenes(prompt):
    return [
        prompt + ", wide cinematic establishing shot",
        prompt + ", closer view, dramatic lighting",
        prompt + ", action moment, intense scene",
        prompt + ", cinematic ending, emotional tone"
    ]

def animate_scene(image_path, output_path, motion):
    img = cv2.imread(image_path)
    h, w, _ = img.shape

    video = cv2.VideoWriter(output_path, cv2.VideoWriter_fourcc(*'mp4v'), 30, (w, h))

    for i in range(60):
        scale = 1 + i * 0.02
        resized = cv2.resize(img, None, fx=scale, fy=scale)
        H, W, _ = resized.shape

        if motion == "zoom":
            x = (W - w)//2
            y = (H - h)//2
        elif motion == "pan_left":
            x = int((W - w) * (i/60))
            y = (H - h)//2
        else:
            x = int((W - w) * (1 - i/60))
            y = (H - h)//2

        frame = resized[y:y+h, x:x+w]
        if frame.shape[:2] == (h, w):
            video.write(frame)

    video.release()

def merge_videos(videos_list, output):
    cap = cv2.VideoCapture(videos_list[0])
    w = int(cap.get(3))
    h = int(cap.get(4))
    cap.release()

    out = cv2.VideoWriter(output, cv2.VideoWriter_fourcc(*'mp4v'), 30, (w, h))

    for v in videos_list:
        cap = cv2.VideoCapture(v)
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            out.write(frame)
        cap.release()

    out.release()

@app.route("/", methods=["GET","POST"])
def index():
    video_path = None

    if request.method == "POST":
        prompt = request.form["prompt"]
        scenes = split_into_scenes(prompt)

        img_paths = []
        for sc in scenes:
            img = pipe(sc).images[0]
            path = f"static/images/{uuid.uuid4()}.png"
            img.save(path)
            img_paths.append(path)

        motions = ["zoom","pan_left","pan_right","zoom"]
        scene_videos = []

        for i, img in enumerate(img_paths):
            vpath = f"static/videos/{uuid.uuid4()}.mp4"
            animate_scene(img, vpath, motions[i])
            scene_videos.append(vpath)

        final = f"static/videos/{uuid.uuid4()}.mp4"
        merge_videos(scene_videos, final)

        video_path = "/" + final

    return render_template("index.html", video_path=video_path)

if __name__ == "__main__":
    app.run(debug=True)
